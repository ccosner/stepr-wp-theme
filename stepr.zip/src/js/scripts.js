import '@popperjs/core';
import 'bootstrap';
//import '@fortawesome/fontawesome-pro/js/solid';
//import '@fortawesome/fontawesome-pro/js/duotone';
