<footer class="site-footer">
    <div class="container">
        <img src="<?php echo esc_url(get_stylesheet_directory_uri() . '/images/stepr-logo-white-v3.svg'); ?>" class="logo" />
        <p>Questions? <a href="mailto:hello@stepr.io">hello@stepr.io</a></p>
    </div>
</footer>