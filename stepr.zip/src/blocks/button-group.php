<div class="button-group">
    <?php echo $content; ?>
</div>