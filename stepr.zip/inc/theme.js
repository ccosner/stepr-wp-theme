export const THEME_PATH = '/wp-content/themes/stepr/images';

export const buttonStyles = [
    { name: "btn-primary", color: "#7d6cb2" },
    { name: "btn-outline-primary", color: "outline" },
    { name: "btn-outline-light", color: "#ffffff" },
    { name: "btn-outline-dark", color: "#212529" }
];